<?php

$shop_name='Shiva & Sons';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive E-commerce Website</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #9746DA;
        }
        .navbar-brand,
        .nav-link,
        .navbar-toggler-icon {
            color: white !important;
        }
        .product-category {
            transition: transform 0.3s ease;
        }
        .product-category:hover {
            transform: scale(1.05);
        }
        .product-image {
            width: 100%;
            height: auto;
        }
        .product-card {
            margin-bottom: 30px;
        }
        .carousel-item img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">Shiva & Son's</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Products
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Mobile</a>
                    <a class="dropdown-item" href="#">Electronics</a>
                    <a class="dropdown-item" href="#">Photography</a>
                </div>
            </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-3" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-light my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>
</nav>

<div class="container mt-5">
    <div class="row text-center">
        <div class="col-md-4 mb-4">
            <div class="product-category p-3 bg-white shadow-sm rounded">
                <img src="https://img.freepik.com/free-photo/elegant-smartphone-composition_23-2149437084.jpg?t=st=1718120175~exp=1718123775~hmac=8566d8656b35b0ad93a524266c9e036cb3bb2cb619009602a294b2b749efe3db&w=740" alt="Mobile" class="img-fluid mb-3">
                <h5>Mobile</h5>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="product-category p-3 bg-white shadow-sm rounded">
                <img src="assets/img/2106.q703.029.S.m004.c10.household appliance realistic.jpg" alt="Electronics" class="img-fluid mb-3">
                <h5>Electronics</h5>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="product-category p-3 bg-white shadow-sm rounded">
                <img src="assets/img/photos.jpg" alt="Photography" class="img-fluid mb-3">
                <h5>Photography</h5>
            </div>
        </div>
    </div>

    <div id="carouselExampleIndicators" class="carousel slide mb-5" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="assets/img/iphone15.jpeg" class="d-block w-100" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="https://img.freepik.com/free-vector/realistic-smartphone-display-with-different-apps_23-2148374061.jpg?t=st=1717959231~exp=1717962831~hmac=1c998cbf246039389a92dc99b5b309ee9cf8f1d9ef2a79ce27804d90c4a77580&w=360" class="d-block w-100" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="https://w7.pngwing.com/pngs/77/285/png-transparent-iphone-8-plus-iphone-7-plus-iphone-5-iphone-x-iphone-6s-iphone-apple-electronics-gadget-mobile-phone-thumbnail.png" class="d-block w-100" alt="Slide 3">
            </div>
            <div class="carousel-item">
                <img src="path/to/image4.jpg" class="d-block w-100" alt="Slide 4">
            </div>
            <div class="carousel-item">
                <img src="path/to/image5.jpg" class="d-block w-100" alt="Slide 5">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="card product-card">
                <img src="path/to/product1.jpg" class="card-img-top product-image" alt="Product 1">
                <div class="card-body text-center">
                    <h5 class="card-title">$99.99</h5>
                    <a href="#" class="btn btn-primary">Add to Cart</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card product-card">
                <img src="path/to/product2.jpg" class="card-img-top product-image" alt="Product 2">
                <div class="card-body text-center">
                    <h5 class="card-title">$199.99</h5>
                    <a href="#" class="btn btn-primary">Add to Cart</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card product-card">
                <img src="path/to/product3.jpg" class="card-img-top product-image" alt="Product 3">
                <div class="card-body text-center">
                    <h5 class="card-title">$299.99</h5>
                    <a href="#" class="btn btn-primary">Add to Cart</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card product-card">
                <img src="path/to/product4.jpg" class="card-img-top product-image" alt="Product 4">
                <div class="card-body text-center">
                    <h5 class="card-title">$399.99</h5>
                    <a href="#" class="btn btn-primary">Add to Cart</a>
                </div>
            </div>
        </div>
    </div>
</div>



<footer class="footer bg-light text-center py-3">
    <div class="container">
        <span>&copy; <span id="year"></span> <?php echo $shop_name; ?>. All rights reserved.</span>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>

